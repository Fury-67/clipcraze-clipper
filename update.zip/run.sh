#!/bin/bash
# ClipCraze Clipper — Linux/Mac launcher
cd "$(dirname "$0")"
if ! command -v python3 &>/dev/null; then
    echo "[ERROR] python3 nahi mila. Pehle install karo."
    exit 1
fi
if [ ! -d venv ]; then
    echo "Pehli dafa setup ho raha hai, thoda wait karo..."
    python3 -m venv venv
fi
. venv/bin/activate
echo "Libraries check/update ho rahi hain..."
pip install --upgrade -r requirements.txt
echo "App khul rahi hai..."
python app.py
