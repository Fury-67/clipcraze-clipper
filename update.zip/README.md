# ClipCraze Clipper 🎬

Tumhare PC pe chalne wali local app — YouTube link do, ye khud **most-replayed
parts** dhoond kar **bohat sare Shorts** bana degi.

## PC me pehle se kya hona chahiye (sirf 1 cheez!)

1. **Python 3.10 ya naya** install karo: https://www.python.org/downloads/
   - ⚠️ Install karte waqt **"Add python.exe to PATH"** wala tick ZAROOR lagana
   - Ye tick bhool gaye to installer dobara chalao → "Modify" → tick lagao

**Bas!** Baqi sab app khud kar legi:
- ✅ Libraries (yt-dlp, OpenCV, Whisper...) — pehli dafa run.bat khud download karega
- ✅ ffmpeg — alag se install karne ki zaroorat NAHI, app ke sath aata hai
- ✅ Face-detection model — folder me pehle se mojood hai
- ✅ AI subtitle model (~75MB) — app ke sath bundled hai, download ki zaroorat nahi

**Zarooraten:** Windows 10/11 (ya Linux/Mac), internet (pehli setup + video
download ke liye), ~2GB khaali disk space.

## Install (sirf pehli dafa)

1. Upar wali **Python** install kar lo (PATH wala tick lazmi)
2. Is folder me **run.bat** pe double-click karo
3. Pehli dafa 3-5 minute lagega (libraries download hongi), phir app khul jayegi

## Istemal

1. YouTube video ka **link paste** karo
2. **Shorts** ki tadaad chuno (1-20), **clip length** (15-60 sec), **quality** (720p/1080p/2K/4K)
3. **Subtitles** chuno: AI Auto-Subtitles (app khud banayegi) / YouTube Captions / Off —
   aur **8 styles** me se koi ek (Classic White, Yellow Pop, Neon Cyan, Meme Bold...)
4. Hook text / "Like & Subscribe!" end card on ya off karo
5. **🚀 START** dabao — progress neeche nazar ayegi
6. Banne ke baad har clip ke sath **⬇ Download button** ayega — jahan marzi save karo
7. Har clip ke sath suggested **title + caption** `clips_info.txt` me hota hai —
   copy karke YouTube pe paste kar dena

## Ye app har Short me kya karti hai

- 📊 Video ka **most-replayed heatmap** parh kar viral parts dhoondti hai
- 🎯 **Face-aware framing** — camera chehron ko follow karta hai (chehre nahi kat te)
- 🤖 **AI subtitles** — app khud audio sun kar subtitles banati hai (8 styles!)
- 💬 Ya YouTube ke captions use karo — jo dil kare
- ⚡ Shuru ke 2.5 sec me **hook text** ("WAIT FOR IT!")
- 🔔 Aakhri 3 sec me **"Like & Subscribe!"**
- ⬇️ Har clip ke sath **Download button**
- 📱 Vertical Shorts-ready MP4 (720p=720x1280, 1080p=1080x1920, 2K=1440x2560, 4K=2160x3840)

## Masle hal karna

- **Download fail ho raha hai?** run.bat dobara chalao (yt-dlp update ho jayegi).
  Phir bhi fail ho to wo video YouTube ne block ki hogi — koi aur link try karo.
- **"Captions nahi mile"** — kuch videos me captions nahi hote, clip phir bhi banega.
- **Bohat slow hai?** Quality 720p rakho, clips ki tadaad kam karo.

## Notes

- Ye app sirf tumhare PC pe chalti hai, koi data kahin nahi bheja jata.
- Dusron ki videos clip karke upload karne se pehle unki clipping permission
  check kar lena (jaise MrBeast clipping allow karte hain).
