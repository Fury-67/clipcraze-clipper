@echo off
REM ClipCraze Clipper — Windows launcher (double-click karo, app.py pe NAHI)
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
    echo.
    echo [ERROR] Python nahi mila!
    echo Pehle install karo: https://www.python.org/downloads/
    echo Install karte waqt "Add python.exe to PATH" wala tick ZAROOR lagana.
    echo.
    pause
    exit /b 1
)

if not exist venv (
    echo Pehli dafa setup ho raha hai, thoda wait karo...
    python -m venv venv
)
call venv\Scripts\activate.bat
echo Libraries install/update ho rahi hain...
pip install --upgrade -r requirements.txt
if errorlevel 1 (
    echo.
    echo [ERROR] Libraries install nahi ho saken! Internet check karo.
    echo Phir is folder ka "venv" folder DELETE karke run.bat dobara chalao.
    echo.
    pause
    exit /b 1
)
echo Libraries test ho rahi hain...
python -c "import yt_dlp, cv2, numpy, imageio_ffmpeg, PIL, faster_whisper; print('sab libraries OK')"
if errorlevel 1 (
    echo.
    echo [ERROR] Koi library missing hai!
    echo Is folder ka "venv" folder DELETE karke run.bat dobara chalao.
    echo.
    pause
    exit /b 1
)
echo.
echo App khul rahi hai...
python app.py
pause
