#!/usr/bin/env python3
"""ClipCraze Clipper — local PC app: YouTube link se auto Shorts banao.

Chalane ke liye: run.bat (Windows) ya run.sh (Linux/Mac) —
ya seedha app.py pe double-click (ye khud apna environment tayyar kar legi).
"""
import os
import sys

APP_DIR = os.path.dirname(os.path.abspath(__file__))


def _venv_python():
    if os.name == "nt":
        return os.path.join(APP_DIR, "venv", "Scripts", "python.exe")
    return os.path.join(APP_DIR, "venv", "bin", "python")


def _in_app_venv():
    try:
        exe = sys.executable or ""
        return (os.path.normcase(os.path.abspath(exe)) ==
                os.path.normcase(os.path.abspath(_venv_python())))
    except Exception:
        return False


def _pause():
    try:
        input("Band karne ke liye Enter dabao...")
    except Exception:
        pass


def _venv_ready(vpy):
    """venv python me zaroori libraries hain? (import kiye baghair check)."""
    import subprocess
    code = ("import importlib.util, sys; mods = ['yt_dlp', 'cv2', 'numpy',"
            " 'imageio_ffmpeg', 'PIL', 'faster_whisper'];"
            " sys.exit(0 if all(importlib.util.find_spec(m) for m in mods)"
            " else 1)")
    try:
        r = subprocess.run([vpy, "-c", code],
                           stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, timeout=120)
        return r.returncode == 0
    except Exception:
        return False


def _ensure_env():
    """Self-bootstrap: agar app apne venv ke bahar chal rahi hai
    (masalan app.py pe double-click), to venv banao, libraries install
    karo, aur khud ko venv wale python se dobara chalao."""
    if os.environ.get("CLIPPER_NO_BOOTSTRAP"):
        return  # testing ke liye bypass
    if _in_app_venv():
        return
    import subprocess
    vpy = _venv_python()
    me = os.path.abspath(__file__)
    try:
        if not os.path.isfile(vpy):
            print("Pehli dafa setup ho raha hai, thoda wait karo...")
            subprocess.run([sys.executable, "-m", "venv",
                            os.path.join(APP_DIR, "venv")], check=True)
        if not _venv_ready(vpy):
            print("Libraries install ho rahi hain, thoda wait karo...")
            req = os.path.join(APP_DIR, "requirements.txt")
            r = subprocess.run([vpy, "-m", "pip", "install", "-r", req])
            if r.returncode != 0 or not _venv_ready(vpy):
                print()
                print("[ERROR] Libraries install nahi ho saken!")
                print("Internet check karo aur dobara chalao.")
                _pause()
                sys.exit(1)
        # ab khud ko venv wale python se dobara chalao
        subprocess.Popen([vpy, me] + sys.argv[1:])
    except Exception as e:
        print(f"[ERROR] Setup fail ho gaya: {e}")
        _pause()
        sys.exit(1)
    sys.exit(0)


_ensure_env()

ROOT = APP_DIR  # app ki folder (restart waghera ke liye)

import os
import queue
import shutil
import subprocess
import sys
import threading
import importlib.util
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

# STARTUP CHECK (engine import se pehle): zaroori libraries mojood hain?
# Agar user app.py pe double-click kare (run.bat ki jagah) to venv ki
# libraries nahi milengi — cryptic error ki jagah saaf message do.
_missing = [m for m in ("yt_dlp", "cv2", "numpy", "imageio_ffmpeg",
                        "PIL", "faster_whisper")
            if importlib.util.find_spec(m) is None]
# CLIPPER_NO_BOOTSTRAP testing me messagebox ke baghair bypass
if _missing and not os.environ.get("CLIPPER_NO_BOOTSTRAP"):
    _r = tk.Tk()
    _r.withdraw()
    messagebox.showerror(
        "Libraries missing ❌",
        "Ye libraries nahi milen:\n" + ", ".join(_missing) + "\n\n"
        "App ko hamesha run.bat se chalao!\n"
        "(app.py pe double-click NA karo)\n\n"
        "run.bat khud venv banata hai aur sab libraries install karta hai.")
    sys.exit(1)

from engine import pipeline, subs, updater

# ---------- theme ----------
BG = "#14141c"        # app background
CARD = "#1e1e2a"      # card background
CARD_EDGE = "#2c2c3e"  # card border
ACCENT = "#ff4b2b"    # ClipCraze red-orange
ACCENT_DARK = "#d63a1f"
GOLD = "#ffb020"
TEXT = "#f2f2f7"
MUTED = "#9d9db5"
ENTRY_BG = "#262637"
LOG_BG = "#101018"


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ClipCraze Clipper — YouTube Shorts Maker")
        self.geometry("720x820")
        self.minsize(680, 600)
        self.configure(bg=BG)
        self.q = queue.Queue()
        self.running = False
        self._style()
        self._build_scroll()
        self._build()
        self.after(100, self._poll)
        # startup pe khamoshi se update check (button highlight hoga agar mile)
        self.after(3000, self._auto_update_check)

    # ---------- styling ----------
    def _style(self):
        s = ttk.Style(self)
        try:
            s.theme_use("clam")
        except tk.TclError:
            pass
        f_big = ("Segoe UI", 11)
        f_small = ("Segoe UI", 10)

        s.configure("TFrame", background=BG)
        s.configure("Card.TFrame", background=CARD)
        s.configure("TLabel", background=BG, foreground=TEXT, font=f_small)
        s.configure("Card.TLabel", background=CARD, foreground=TEXT,
                    font=f_small)
        s.configure("Title.TLabel", background=BG, foreground=TEXT,
                    font=("Segoe UI", 20, "bold"))
        s.configure("Sub.TLabel", background=BG, foreground=MUTED,
                    font=("Segoe UI", 10))
        s.configure("Head.TLabel", background=CARD, foreground=GOLD,
                    font=("Segoe UI", 11, "bold"))
        s.configure("Muted.TLabel", background=BG, foreground=MUTED,
                    font=("Segoe UI", 9))
        s.configure("Status.TLabel", background=BG, foreground=GOLD,
                    font=("Segoe UI", 10, "bold"))

        s.configure("TButton", background="#2a2a3c", foreground=TEXT,
                    font=f_small, padding=7, borderwidth=0)
        s.map("TButton",
              background=[("active", "#34344a"), ("disabled", "#22222e")],
              foreground=[("disabled", "#6a6a80")])
        s.configure("Accent.TButton", background=ACCENT, foreground="white",
                    font=("Segoe UI", 13, "bold"), padding=10, borderwidth=0)
        s.map("Accent.TButton",
              background=[("active", ACCENT_DARK), ("disabled", "#5a2a20")],
              foreground=[("disabled", "#a08070")])
        s.configure("Ghost.TButton", background=CARD_EDGE, foreground=TEXT,
                    font=f_small, padding=6, borderwidth=0)
        s.map("Ghost.TButton", background=[("active", "#3a3a52")])

        s.configure("TEntry", fieldbackground=ENTRY_BG, foreground=TEXT,
                    insertcolor=TEXT, borderwidth=0, padding=8,
                    font=("Segoe UI", 11))
        s.configure("TCombobox", fieldbackground=ENTRY_BG, foreground=TEXT,
                    background=ENTRY_BG, arrowcolor=TEXT, borderwidth=0,
                    padding=6, font=f_small)
        s.map("TCombobox", fieldbackground=[("readonly", ENTRY_BG)])
        self.option_add("*TCombobox*Listbox.background", ENTRY_BG)
        self.option_add("*TCombobox*Listbox.foreground", TEXT)
        self.option_add("*TCombobox*Listbox.selectBackground", ACCENT)
        s.configure("TSpinbox", fieldbackground=ENTRY_BG, foreground=TEXT,
                    background=ENTRY_BG, arrowcolor=TEXT, borderwidth=0,
                    padding=6, font=f_small)
        s.configure("TCheckbutton", background=CARD, foreground=TEXT,
                    font=f_small)
        s.map("TCheckbutton", background=[("active", CARD)])
        s.configure("TProgressbar", background=ACCENT, troughcolor=CARD_EDGE,
                    borderwidth=0, thickness=10)
        s.configure("Vertical.TScrollbar", background=CARD_EDGE,
                    troughcolor=BG, borderwidth=0, arrowcolor=MUTED)

    # ---------- layout helpers ----------
    def _entry_menu(self, entry):
        """Right-click menu: Cut/Copy/Paste/Delete/Select All (mouse se)."""
        menu = tk.Menu(entry, tearoff=0, bg=CARD_EDGE, fg=TEXT,
                       activebackground=ACCENT, activeforeground="white",
                       font=("Segoe UI", 10))
        menu.add_command(label="✂ Cut",
                         command=lambda: entry.event_generate("<<Cut>>"))
        menu.add_command(label="⧉ Copy",
                         command=lambda: entry.event_generate("<<Copy>>"))
        menu.add_command(label="📋 Paste",
                         command=lambda: entry.event_generate("<<Paste>>"))
        menu.add_command(
            label="⌫ Delete",
            command=lambda: (entry.delete("sel.first", "sel.last")
                             if entry.select_present() else None))
        menu.add_separator()
        menu.add_command(label="Select All",
                         command=lambda: entry.select_range(0, "end"))

        def show(e):
            entry.focus_set()
            menu.tk_popup(e.x_root, e.y_root)

        entry.bind("<Button-3>", show)  # Windows/Linux right-click
        entry.bind("<Button-2>", show)  # macOS
        return entry

    def _build_scroll(self):
        """Poora content scrollable — chhoti screen pe bhi sab nazar aye."""
        self.canvas = tk.Canvas(self, bg=BG, highlightthickness=0)
        self.vsb = ttk.Scrollbar(self, orient="vertical",
                                 style="Vertical.TScrollbar",
                                 command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.vsb.set)
        self.vsb.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.content = ttk.Frame(self.canvas)
        self._win = self.canvas.create_window((0, 0), window=self.content,
                                              anchor="nw")

        def _on_config(_e):
            self.canvas.configure(scrollregion=self.canvas.bbox("all"))
            self.canvas.itemconfig(self._win, width=self.canvas.winfo_width())

        self.content.bind("<Configure>", _on_config)
        self.canvas.bind("<Configure>",
                         lambda _e: self.canvas.itemconfig(
                             self._win, width=self.canvas.winfo_width()))
        # mouse wheel scrolling
        self.canvas.bind_all("<MouseWheel>",
                             lambda e: self.canvas.yview_scroll(
                                 -1 * (e.delta // 120), "units"))
        self.canvas.bind_all("<Button-4>",
                             lambda _e: self.canvas.yview_scroll(-1, "units"))
        self.canvas.bind_all("<Button-5>",
                             lambda _e: self.canvas.yview_scroll(1, "units"))

    def _card(self, parent, title):
        outer = ttk.Frame(parent, style="Card.TFrame", padding=2)
        outer.pack(fill="x", padx=14, pady=6)
        inner = ttk.Frame(outer, style="Card.TFrame", padding=(14, 10))
        inner.pack(fill="x")
        ttk.Label(inner, text=title, style="Head.TLabel").pack(anchor="w",
                                                               pady=(0, 8))
        inner._outer = outer  # hide/show ke liye
        return inner

    def _build(self):
        C = self.content  # scrollable container
        # header
        hdr = ttk.Frame(C, padding=(16, 14, 16, 4))
        hdr.pack(fill="x")
        row = ttk.Frame(hdr)
        row.pack(fill="x")
        dot = tk.Label(row, text="✂", bg=BG, fg=ACCENT,
                       font=("Segoe UI", 26, "bold"))
        dot.pack(side="left", padx=(0, 10))
        tcol = ttk.Frame(row)
        tcol.pack(side="left")
        ttk.Label(tcol, text="ClipCraze Clipper",
                  style="Title.TLabel").pack(anchor="w")
        ttk.Label(tcol, text="YouTube link do — most-replayed Shorts khud ban jayenge",
                  style="Sub.TLabel").pack(anchor="w")
        # update button (right side)
        ucol = ttk.Frame(row)
        ucol.pack(side="right", anchor="n")
        self.ver_label = ttk.Label(ucol, text="v" + updater.local_version(),
                                   style="Muted.TLabel")
        self.ver_label.pack(anchor="e")
        self.update_btn = ttk.Button(ucol, text="🔄 Check for Updates",
                                     style="Ghost.TButton",
                                     command=self._update_clicked)
        self.update_btn.pack(anchor="e", pady=(4, 0))

        # 1) link
        c1 = self._card(C, "🔗  Video Link")
        self.url_var = tk.StringVar()
        link_entry = self._entry_menu(ttk.Entry(c1, textvariable=self.url_var))
        link_entry.pack(fill="x")
        link_entry.insert(0, "")
        self._placeholder(link_entry, "https://www.youtube.com/watch?v=...  (link yahan paste karo)")
        link_entry.bind("<Return>", lambda _e: self._start())  # Enter = START
        ttk.Label(c1, text="Koi bhi public YouTube video — podcast, stream, vlog  (right-click: Copy/Paste, Enter: Start)",
                  style="Muted.TLabel", background=CARD).pack(anchor="w", pady=(6, 0))
        # moments mode: auto ya manual
        moderow = ttk.Frame(c1, style="Card.TFrame")
        moderow.pack(fill="x", pady=(8, 0))
        ttk.Label(moderow, text="Moments:", style="Card.TLabel").pack(
            side="left")
        self.mode_var = tk.StringVar(value="🤖 Auto (AI khud dhoonde)")
        ttk.Combobox(moderow, width=30, textvariable=self.mode_var,
                     values=["🤖 Auto (AI khud dhoonde)",
                             "✋ Manual (mein khud time bataunga)"],
                     state="readonly").pack(side="left", padx=8)
        self.mode_var.trace_add("write", lambda *_: self._toggle_manual())

        # 1b) manual moments card (sirf manual mode me nazar ayega)
        self.c1 = c1
        self.manual_card = self._card(C, "✋  Manual Moments")
        brow = ttk.Frame(self.manual_card, style="Card.TFrame")
        brow.pack(fill="x")
        self.dl_preview_btn = ttk.Button(
            brow, text="📥 Video Download Karo",
            command=self._download_preview)
        self.dl_preview_btn.pack(side="left")
        self.watch_btn = ttk.Button(
            brow, text="👁 Video Dekho",
            command=self._open_preview, state="disabled")
        self.watch_btn.pack(side="left", padx=8)
        self.preview_status = ttk.Label(brow, text="",
                                        style="Muted.TLabel",
                                        background=CARD)
        self.preview_status.pack(side="left", padx=8)
        ttk.Label(self.manual_card,
                  text="Video download karke apne player (VLC) me dekho, "
                       "pasandida hisse ka Start/End time (MM:SS) note karke "
                       "neeche likho — utne hi clips banenge.",
                  style="Muted.TLabel", background=CARD,
                  wraplength=620, justify="left").pack(anchor="w",
                                                       pady=(8, 0))
        seghead = ttk.Frame(self.manual_card, style="Card.TFrame")
        seghead.pack(fill="x", pady=(8, 2))
        ttk.Label(seghead, text="Start", style="Card.TLabel",
                  width=12).pack(side="left")
        ttk.Label(seghead, text="End", style="Card.TLabel",
                  width=12).pack(side="left")
        self.seg_frame = ttk.Frame(self.manual_card, style="Card.TFrame")
        self.seg_frame.pack(fill="x")
        self.segments = []  # [(start_var, end_var, row_frame), ...]
        self.preview_src = None
        self.preview_url = ""
        self.preview_quality = ""
        self._add_segment_row()
        ttk.Button(self.manual_card, text="+ Segment Add Karo",
                   command=self._add_segment_row).pack(anchor="w",
                                                      pady=(6, 0))
        self.manual_card._outer.pack_forget()  # shuru me chhupa hua

        # 2) clip settings
        c2 = self._card(C, "⚙️  Clip Settings")
        grid = ttk.Frame(c2, style="Card.TFrame")
        grid.pack(fill="x")
        for col in range(6):
            grid.columnconfigure(col, weight=1)

        ttk.Label(grid, text="Shorts:", style="Card.TLabel").grid(
            row=0, column=0, sticky="w", pady=4)
        self.num_var = tk.StringVar(value="10")
        ttk.Spinbox(grid, from_=1, to=20, width=5,
                    textvariable=self.num_var).grid(
            row=0, column=1, sticky="w", padx=(0, 12), pady=4)

        ttk.Label(grid, text="Length:", style="Card.TLabel").grid(
            row=0, column=2, sticky="w", pady=4)
        self.len_var = tk.StringVar(value="Auto 🎯")
        ttk.Combobox(grid, width=9, textvariable=self.len_var,
                     values=["Auto 🎯", "15", "20", "30", "45", "60"],
                     state="readonly").grid(
            row=0, column=3, sticky="w", padx=(4, 4), pady=4)
        ttk.Label(grid, text="sec  (Auto: har clip ki length khud tay)",
                  style="Muted.TLabel", background=CARD).grid(
            row=0, column=4, sticky="w", pady=4)

        ttk.Label(grid, text="Quality:", style="Card.TLabel").grid(
            row=1, column=0, sticky="w", pady=4)
        self.q_var = tk.StringVar(value="720p")
        ttk.Combobox(grid, width=10, textvariable=self.q_var,
                     values=["720p", "1080p", "2K", "4K"],
                     state="readonly").grid(
            row=1, column=1, columnspan=2, sticky="w", pady=4)
        ttk.Label(grid, text="(output video ki quality)",
                  style="Muted.TLabel", background=CARD).grid(
            row=1, column=3, columnspan=3, sticky="w", padx=6, pady=4)

        ttk.Label(grid, text="Format:", style="Card.TLabel").grid(
            row=2, column=0, sticky="w", pady=4)
        self.format_var = tk.StringVar(value="📱 Vertical 9:16")
        ttk.Combobox(grid, width=22, textvariable=self.format_var,
                     values=["📱 Vertical 9:16 (Shorts/TikTok)",
                             "🖥️ Landscape 16:9 (YouTube Video)"],
                     state="readonly").grid(
            row=2, column=1, columnspan=3, sticky="w", pady=4)
        ttk.Label(grid, text="(Shorts = vertical, YouTube video = landscape)",
                  style="Muted.TLabel", background=CARD).grid(
            row=2, column=4, columnspan=2, sticky="w", padx=6, pady=4)

        # 3) subtitles
        c3 = self._card(C, "💬  Subtitles")
        srow = ttk.Frame(c3, style="Card.TFrame")
        srow.pack(fill="x")
        ttk.Label(srow, text="Mode:", style="Card.TLabel").pack(side="left")
        self.submode_var = tk.StringVar(value="AI Auto-Subtitles")
        ttk.Combobox(srow, width=18, textvariable=self.submode_var,
                     values=["AI Auto-Subtitles", "YouTube Captions", "Off"],
                     state="readonly").pack(side="left", padx=8)
        ttk.Label(srow, text="Style:", style="Card.TLabel").pack(
            side="left", padx=(12, 0))
        self.substyle_var = tk.StringVar(value=subs.STYLE_GUI_NAMES[0])
        ttk.Combobox(srow, width=14, textvariable=self.substyle_var,
                     values=subs.STYLE_GUI_NAMES,
                     state="readonly").pack(side="left", padx=8)
        ttk.Label(srow, text="Language:", style="Card.TLabel").pack(
            side="left", padx=(12, 0))
        self.sublang_var = tk.StringVar(value="Video ki zaban (Auto)")
        ttk.Combobox(srow, width=20, textvariable=self.sublang_var,
                     values=["Video ki zaban (Auto)", "English (Translate)"],
                     state="readonly").pack(side="left", padx=8)
        ttk.Label(c3, text="AI khud sun kar subtitles banata hai — model app ke sath included hai",
                  style="Muted.TLabel", background=CARD).pack(anchor="w", pady=(6, 0))

        # 4) hook + CTA
        c4 = self._card(C, "✨  Hook & Ending")
        hrow = ttk.Frame(c4, style="Card.TFrame")
        hrow.pack(fill="x")
        self.hook_on = tk.BooleanVar(value=True)
        ttk.Checkbutton(hrow, text="Hook text (pehle 2 sec):",
                        variable=self.hook_on).pack(side="left")
        self.hook_var = tk.StringVar(value="WAIT FOR IT!")
        self._entry_menu(ttk.Entry(hrow, textvariable=self.hook_var,
                                   width=20)).pack(side="left", padx=8)
        self.cta_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(hrow, text="End me 'Like & Subscribe!' card",
                        variable=self.cta_var).pack(side="left", padx=(12, 0))
        # watermark: Yes/No + text
        wrow = ttk.Frame(c4, style="Card.TFrame")
        wrow.pack(fill="x", pady=(8, 0))
        self.wm_on = tk.BooleanVar(value=False)
        ttk.Checkbutton(wrow, text="Watermark:",
                        variable=self.wm_on).pack(side="left")
        self.wm_var = tk.StringVar(value="@ClipCrazeShorts")
        self._entry_menu(ttk.Entry(wrow, textvariable=self.wm_var,
                                   width=22)).pack(side="left", padx=8)
        ttk.Label(wrow, text="(har clip ke upar-dayen kone me halka text)",
                  style="Muted.TLabel", background=CARD).pack(side="left")

        # 5) folder + start
        c5 = self._card(C, "📁  Save Folder")
        frow = ttk.Frame(c5, style="Card.TFrame")
        frow.pack(fill="x")
        default_out = os.path.join(os.path.expanduser("~"),
                                   "ClipCraze Shorts")
        self.out_var = tk.StringVar(value=default_out)
        self._entry_menu(ttk.Entry(frow, textvariable=self.out_var)).pack(
            side="left", fill="x", expand=True, padx=(0, 8))
        ttk.Button(frow, text="Browse…", style="Ghost.TButton",
                   command=self._browse).pack(side="left")

        # start
        srow2 = ttk.Frame(C, padding=(14, 8))
        srow2.pack(fill="x")
        self.start_btn = ttk.Button(srow2, text="🚀  START — Shorts Banao",
                                    style="Accent.TButton",
                                    command=self._start)
        self.start_btn.pack(fill="x")
        self.prog = ttk.Progressbar(srow2, mode="determinate", maximum=100)
        self.prog.pack(fill="x", pady=(10, 4))
        self.status_var = tk.StringVar(
            value="Link paste karo aur START dabao 👍")
        ttk.Label(srow2, textvariable=self.status_var,
                  style="Status.TLabel").pack(anchor="w")

        # log
        logfr = ttk.Frame(C, padding=(14, 2, 14, 12))
        logfr.pack(fill="both", expand=True)
        self.log = tk.Text(logfr, height=9, wrap="word", state="disabled",
                           bg=LOG_BG, fg="#c8c8dc", insertbackground=TEXT,
                           relief="flat", padx=10, pady=8,
                           font=("Consolas", 9))
        sb = ttk.Scrollbar(logfr, orient="vertical",
                           style="Vertical.TScrollbar",
                           command=self.log.yview)
        self.log.configure(yscrollcommand=sb.set)
        self.log.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

    def _placeholder(self, entry, text):
        entry.configure(foreground="#6a6a80")
        entry.insert(0, text)

        def on_focus_in(_e):
            if entry.get() == text:
                entry.delete(0, "end")
                entry.configure(foreground=TEXT)

        def on_focus_out(_e):
            if not entry.get():
                entry.insert(0, text)
                entry.configure(foreground="#6a6a80")

        entry.bind("<FocusIn>", on_focus_in)
        entry.bind("<FocusOut>", on_focus_out)
        self._link_placeholder = text

    def _link_value(self):
        v = self.url_var.get().strip()
        if v == getattr(self, "_link_placeholder", ""):
            return ""
        return v

    # ---------- actions ----------
    def _browse(self):
        d = filedialog.askdirectory()
        if d:
            self.out_var.set(d)

    def _open_folder(self):
        path = self.out_var.get()
        if os.path.isdir(path):
            if os.name == "nt":
                os.startfile(path)
            elif sys.platform == "darwin":
                subprocess.run(["open", path])
            else:
                subprocess.run(["xdg-open", path])

    def _download_clip(self, path):
        dest = filedialog.asksaveasfilename(
            initialfile=os.path.basename(path),
            defaultextension=".mp4",
            filetypes=[("MP4 video", "*.mp4"), ("All files", "*.*")])
        if dest:
            try:
                shutil.copy2(path, dest)
                messagebox.showinfo("Download",
                                    f"Save ho gaya ✅\n{dest}")
            except Exception as e:
                messagebox.showerror("Error", f"Save nahi hua: {e}")

    def _show_results(self, clips):
        """Har clip ke sath Download button wali window."""
        win = tk.Toplevel(self)
        win.title(f"{len(clips)} Shorts ready 🎉")
        win.geometry("600x440")
        win.configure(bg=BG)

        hdr = tk.Label(win, text=f"🎉 {len(clips)} Shorts ready hain!",
                       bg=BG, fg=GOLD, font=("Segoe UI", 14, "bold"))
        hdr.pack(pady=(14, 4))
        tk.Label(win, text="Har clip ke samne Download dabao — jahan chaho save karo",
                 bg=BG, fg=MUTED, font=("Segoe UI", 10)).pack(pady=(0, 8))

        canvas = tk.Canvas(win, bg=BG, highlightthickness=0)
        sb = ttk.Scrollbar(win, orient="vertical",
                           style="Vertical.TScrollbar",
                           command=canvas.yview)
        frame = ttk.Frame(canvas, style="Card.TFrame", padding=6)
        frame.bind("<Configure>",
                   lambda e: canvas.configure(
                       scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=frame, anchor="nw")
        canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side="left", fill="both", expand=True, padx=(14, 0))
        sb.pack(side="right", fill="y", padx=(0, 14))

        for item in clips:
            # naya format: (path, title, caption) — purana: sirf path
            if isinstance(item, (list, tuple)):
                path, title, caption = item[0], item[1], item[2]
            else:
                path, title, caption = item, "", ""
            row = ttk.Frame(frame, style="Card.TFrame", padding=(10, 8))
            row.pack(fill="x", padx=6, pady=4)
            name = os.path.basename(path)
            try:
                mb = os.path.getsize(path) // 1024 // 1024
                label = f"{name}\n({mb} MB)"
            except OSError:
                label = name
            ttk.Label(row, text=label, style="Card.TLabel",
                      font=("Segoe UI", 10)).pack(side="left", fill="x",
                                                  expand=True)
            if title or caption:
                ttk.Button(row, text="📋 Caption", style="Ghost.TButton",
                           command=lambda t=title, c=caption:
                           self._show_caption(t, c)
                           ).pack(side="right", padx=(10, 0))
            ttk.Button(row, text="⬇ Download", style="Ghost.TButton",
                       command=lambda p=path: self._download_clip(p)
                       ).pack(side="right", padx=(10, 0))

        brow = ttk.Frame(win, padding=12)
        brow.pack(fill="x")
        ttk.Button(brow, text="📁  Folder Kholo", style="Accent.TButton",
                   command=self._open_folder).pack(fill="x")

    def _show_caption(self, title, caption):
        """Clip ka suggested YouTube title + caption dikhao, copy ke sath."""
        win = tk.Toplevel(self)
        win.title("YouTube Caption 📋")
        win.geometry("480x360")
        win.configure(bg=BG)

        tk.Label(win, text="Is clip ka suggested caption:",
                 bg=BG, fg=GOLD,
                 font=("Segoe UI", 12, "bold")).pack(pady=(14, 6))
        txt = tk.Text(win, bg=CARD, fg="#ffffff",
                      font=("Segoe UI", 11), wrap="word",
                      relief="flat", padx=12, pady=12)
        txt.pack(fill="both", expand=True, padx=14)
        full = f"{title}\n\n{caption}" if title else caption
        txt.insert("1.0", full)
        txt.configure(state="disabled")

        def copy_all():
            win.clipboard_clear()
            win.clipboard_append(full)
            messagebox.showinfo("Copy ✅",
                                "Title + Caption copy ho gaya!\n"
                                "YouTube pe paste kar do.")

        ttk.Button(win, text="📋 Copy Karo", style="Accent.TButton",
                   command=copy_all).pack(fill="x", padx=14, pady=12)

    def _log(self, msg):
        self.log.configure(state="normal")
        self.log.insert("end", msg + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def _toggle_manual(self):
        """Manual mode select ho to manual card dikhao, warna chhupao."""
        if self.mode_var.get().startswith("✋"):
            self.manual_card._outer.pack(fill="x", padx=14, pady=6,
                                         after=self.c1._outer)
        else:
            self.manual_card._outer.pack_forget()

    def _add_segment_row(self):
        row = ttk.Frame(self.seg_frame, style="Card.TFrame")
        row.pack(fill="x", pady=2)
        s_var = tk.StringVar()
        s_e = self._entry_menu(ttk.Entry(row, textvariable=s_var, width=10))
        s_e.pack(side="left")
        self._placeholder(s_e, "MM:SS")
        e_var = tk.StringVar()
        e_e = self._entry_menu(ttk.Entry(row, textvariable=e_var, width=10))
        e_e.pack(side="left", padx=(8, 0))
        self._placeholder(e_e, "MM:SS")
        idx = len(self.segments)
        ttk.Button(row, text="✕", width=3,
                   command=lambda: self._remove_segment_row(idx)).pack(
            side="left", padx=8)
        self.segments.append([s_var, e_var, row])
        # har row ke button ka index refresh karo
        for i, (_s, _e, r) in enumerate(self.segments):
            for child in r.winfo_children():
                if isinstance(child, ttk.Button):
                    child.configure(
                        command=lambda i=i: self._remove_segment_row(i))

    def _remove_segment_row(self, idx):
        if len(self.segments) <= 1:
            return  # kam az kam ek row rahe
        _s, _e, row = self.segments.pop(idx)
        row.destroy()
        for i, (_s2, _e2, r) in enumerate(self.segments):
            for child in r.winfo_children():
                if isinstance(child, ttk.Button):
                    child.configure(
                        command=lambda i=i: self._remove_segment_row(i))

    @staticmethod
    def _parse_time(s):
        """'MM:SS', 'HH:MM:SS' ya seconds -> float seconds (ya None)."""
        s = (s or "").strip()
        if not s or s == "MM:SS":
            return None
        try:
            parts = [float(p) for p in s.split(":")]
        except ValueError:
            return None
        if len(parts) == 1:
            return parts[0] if parts[0] >= 0 else None
        if len(parts) == 2:
            return parts[0] * 60 + parts[1]
        if len(parts) == 3:
            return parts[0] * 3600 + parts[1] * 60 + parts[2]
        return None

    def _download_preview(self):
        url = self._link_value()
        if not url:
            messagebox.showwarning("Link missing",
                                   "Pehle YouTube link paste karo!")
            return
        self.dl_preview_btn.configure(state="disabled")
        self.preview_status.configure(text="Download ho rahi hai...")
        t = threading.Thread(target=self._dl_preview_worker, args=(url,),
                             daemon=True)
        t.start()

    def _dl_preview_worker(self, url):
        try:
            from engine import ytdlp_wrap
            import hashlib
            preview_dir = os.path.join(os.path.expanduser("~"),
                                       "ClipCraze Shorts", ".preview")
            os.makedirs(preview_dir, exist_ok=True)
            vid = hashlib.md5(url.encode()).hexdigest()[:10]
            quality = self.q_var.get()
            path = os.path.join(preview_dir,
                                f"preview_{vid}_{quality}.mp4")
            if os.path.isfile(path) and os.path.getsize(path) > 1024 * 1024:
                msg = "Preview pehle se download hai ✓"
            else:
                msg = "Preview download ho rahi hai..."
                self.after(0, lambda: self._log(msg))
                ytdlp_wrap.download(url, path, quality, None)
                msg = "Preview download complete ✓"
            self.preview_src = path
            self.preview_url = url
            self.preview_quality = quality
            self.after(0, lambda: self.preview_status.configure(text=msg))
            self.after(0, lambda: self.watch_btn.configure(state="normal"))
            self.after(0, lambda: self._log(
                msg + " — '👁 Video Dekho' dabao, time note karo!"))
        except Exception as e:
            self.after(0, lambda: self._log(f"Preview download fail: {e}"))
            self.after(0, lambda: self.preview_status.configure(text="Fail"))
        finally:
            self.after(0, lambda: self.dl_preview_btn.configure(
                state="normal"))

    def _open_preview(self):
        path = self.preview_src
        if not path or not os.path.isfile(path):
            self._log("Pehle '📥 Video Download Karo' dabao!")
            return
        try:
            if os.name == "nt":
                os.startfile(path)  # noqa: S606
            else:
                subprocess.Popen(["xdg-open", path])
            self._log("Video khul gayi — pasandida hisson ka time note karo! ⏱")
        except Exception as e:
            self._log(f"Video nahi khul saki: {e}")

    def _start(self):
        url = self._link_value()
        if not url:
            messagebox.showwarning("Link missing",
                                   "Pehle YouTube link paste karo!")
            return
        try:
            num = int(self.num_var.get())
        except ValueError:
            messagebox.showwarning("Galat value",
                                   "Shorts ki tadaad theek karo.")
            return
        lv = self.len_var.get()
        # "Auto 🎯" -> app khud har clip ki length tay karegi (15..60s)
        length = "auto" if lv.startswith("Auto") else int(lv)
        # manual mode: segments jama karo
        manual_segments = None
        src_file = None
        if self.mode_var.get().startswith("✋"):
            segs = []
            for s_var, e_var, _row in self.segments:
                s = self._parse_time(s_var.get())
                e = self._parse_time(e_var.get())
                if s is None or e is None or e <= s:
                    continue
                segs.append((s, e))
            if not segs:
                messagebox.showwarning(
                    "Koi segment nahi",
                    "Manual mode: kam az kam ek sahi Start/End time likho "
                    "(masalan 05:30 se 06:15)!")
                return
            manual_segments = segs
            num = len(segs)
            # preview wali download reuse karo (dobara download nahi)
            if (self.preview_src and os.path.isfile(self.preview_src)
                    and self.preview_url == url
                    and self.preview_quality == self.q_var.get()):
                src_file = self.preview_src
                self._log("Preview wali video reuse ho rahi hai ⏩ "
                          "(dobara download nahi)")
        self.running = True
        self.start_btn.configure(state="disabled")
        self.prog["value"] = 0
        self._log("=" * 50)
        t = threading.Thread(target=self._worker,
                             args=(url, num, length,
                                   manual_segments, src_file),
                             daemon=True)
        t.start()

    def _worker(self, url, num, length, manual_segments=None,
                src_file=None):
        mode_map = {"AI Auto-Subtitles": "ai",
                    "YouTube Captions": "youtube", "Off": "off"}
        try:
            made = pipeline.run_pipeline(
                url,
                out_dir=self.out_var.get(),
                num_clips=num,
                clip_len=length,
                quality=self.q_var.get(),
                subtitle_mode=mode_map.get(self.submode_var.get(), "ai"),
                subtitle_style=subs.GUI_TO_KEY.get(
                    self.substyle_var.get(), "classic"),
                subtitle_lang=("en" if self.sublang_var.get().startswith(
                    "English") else "auto"),
                aspect=("16:9" if "16:9" in self.format_var.get()
                        else "9:16"),
                hook_text=self.hook_var.get().strip()
                if self.hook_on.get() else "",
                with_cta=self.cta_var.get(),
                watermark=(self.wm_var.get().strip()
                           if self.wm_on.get() else ""),
                manual_segments=manual_segments,
                src_file=src_file,
                cb=self._cb,
            )
            self.q.put(("done", made))
        except Exception as e:
            self.q.put(("error", str(e)))

    def _cb(self, kind, *args):
        self.q.put((kind,) + args)

    def _poll(self):
        try:
            while True:
                msg = self.q.get_nowait()
                kind = msg[0]
                if kind == "log":
                    self._log(msg[1])
                elif kind == "progress":
                    self.prog["value"] = msg[1] * 100
                    self.status_var.set(msg[2] if len(msg) > 2 else "")
                elif kind == "done":
                    self.running = False
                    self.start_btn.configure(state="normal")
                    self.status_var.set("Ho gaya! 🎉")
                    clips = msg[1] if len(msg) > 1 else []
                    messagebox.showinfo("Done",
                                        f"{len(clips)} Shorts ban gaye! 🎉")
                    if clips:
                        self._show_results(clips)
                elif kind == "update_done":
                    self._on_update_done(msg[1] if len(msg) > 1 else "?")
                elif kind == "update_error":
                    self.update_btn.configure(state="normal",
                                              text="🔄 Check for Updates")
                    self.status_var.set("Update fail!")
                    self._log("UPDATE ERROR: " + msg[1])
                    messagebox.showerror("Update fail", msg[1])
                elif kind == "error":
                    self.running = False
                    self.start_btn.configure(state="normal")
                    self.status_var.set("Error! Neeche dekho 👇")
                    self._log("ERROR: " + msg[1])
                    messagebox.showerror("Error", msg[1])
        except queue.Empty:
            pass
        self.after(100, self._poll)

    # ---------- auto-updater ----------
    def _update_clicked(self):
        self.update_btn.configure(state="disabled",
                                  text="🔄 Check ho raha hai...")
        threading.Thread(target=self._update_check_worker, args=(False,),
                         daemon=True).start()

    def _update_check_worker(self, silent):
        available, remote_ver, err = updater.check()
        lv = updater.local_version()

        def done():
            self.update_btn.configure(state="normal")
            if err:
                self.update_btn.configure(text="🔄 Check for Updates")
                if not silent:
                    messagebox.showwarning("Update check", err)
                return
            if available:
                self.update_btn.configure(text="⬇ Update Available!")
                self._log(f"Naya update mila: v{lv} -> v{remote_ver} 🎉")
                if silent:
                    return
                if messagebox.askyesno(
                        "Update available",
                        f"Naya version v{remote_ver} aya hai "
                        f"(tumhare paas v{lv}).\nInstall karun?"):
                    self._install_update()
            else:
                self.update_btn.configure(text="🔄 Check for Updates")
                if not silent:
                    messagebox.showinfo("Up to date",
                                        f"Tumhari app latest hai ✅ (v{lv})")
        self.after(0, done)

    def _install_update(self):
        self._log("=" * 50)
        self.update_btn.configure(state="disabled", text="⬇ Installing...")
        self.status_var.set("Update install ho raha hai...")

        def worker():
            try:
                def prog(f):
                    self.q.put(("progress", f, "Update download..."))
                rv = updater.apply_update(
                    cb_log=lambda m: self.q.put(("log", m)), cb_prog=prog)
                self.q.put(("update_done", rv))
            except Exception as e:
                self.q.put(("update_error", str(e)))

        threading.Thread(target=worker, daemon=True).start()

    def _on_update_done(self, rv):
        self.update_btn.configure(state="normal",
                                  text="🔄 Check for Updates")
        self.ver_label.configure(text="v" + rv)
        self.status_var.set("Update complete!")
        messagebox.showinfo(
            "Update complete",
            f"App v{rv} pe update ho gayi! 🎉\n\n"
            "Ab app khud restart hogi...")
        self._restart_app()

    def _restart_app(self):
        """Update ke baad app khud band ho kar dobara khul jaye —
        user ko manually restart nahi karna parega."""
        try:
            app_py = os.path.join(ROOT, "app.py")
            subprocess.Popen(
                [sys.executable, app_py],
                cwd=ROOT,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL)
        except Exception as e:
            messagebox.showerror(
                "Restart fail",
                f"App khud restart nahi ho saki ({e}).\n"
                "Please app band karke dobara kholo.")
            return
        try:
            self.root.destroy()
        finally:
            os._exit(0)

    def _auto_update_check(self):
        """Startup pe khamoshi se check — mile to button highlight."""
        threading.Thread(target=self._update_check_worker, args=(True,),
                         daemon=True).start()


if __name__ == "__main__":
    App().mainloop()
