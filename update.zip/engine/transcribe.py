"""AI auto-subtitles: faster-whisper se audio -> text segments.

Model app ke sath bundled hai (models/whisper-tiny, ~75MB) — dobara
download ki zaroorat nahi. Import lazy hai taake app jaldi khule.

Note: wav ko hum khud numpy me load karte hain (wave module se) —
faster-whisper ka PyAV-based decode_audio kuch av versions ke sath
toota hua hai, is liye us raste se bachte hain.
"""
import os
import threading
import wave

import numpy as np

_model = None
_base_model = None
_lock = threading.Lock()  # parallel clips me model shared hai
_base_lock = threading.Lock()  # base model ki loading ke liye alag lock

# log me khubsurat naam ke liye
LANG_NAMES = {
    "en": "English", "hi": "Hindi", "ur": "Urdu", "pa": "Punjabi",
    "bn": "Bengali", "ar": "Arabic", "fa": "Farsi", "tr": "Turkish",
    "es": "Spanish", "fr": "French", "de": "German", "pt": "Portuguese",
    "ru": "Russian", "id": "Indonesian", "ms": "Malay",
}


def _models_dir():
    return os.path.join(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__))), "models")


def _get_model():
    global _model
    if _model is None:
        from faster_whisper import WhisperModel
        bundled = os.path.join(_models_dir(), "whisper-tiny")
        if os.path.isfile(os.path.join(bundled, "model.bin")):
            _model = WhisperModel(bundled, device="cpu", compute_type="int8")
        else:
            # fallback: pehli dafa internet se download ho jayega
            _model = WhisperModel("tiny", device="cpu", compute_type="int8")
    return _model


def _get_translate_model(log=None):
    """Hindi/Urdu -> English translation ke liye bara model (base, ~145MB).

    Pehli dafa internet se download hota hai (models/ me save ho jata
    hai, updater usay kabhi nahi chherta), uske baad offline chalta hai.
    Download fail ho to chhote model pe fallback.
    """
    global _base_model
    if _base_model is None:
        with _base_lock:
            if _base_model is None:
                from faster_whisper import WhisperModel
                try:
                    if log:
                        log("Behtar English translation ke liye base model "
                            "tayyar ho raha hai (pehli dafa ~145MB download, "
                            "uske baad offline)...")
                    _base_model = WhisperModel(
                        "base", device="cpu", compute_type="int8",
                        download_root=_models_dir())
                except Exception as e:
                    if log:
                        log(f"Base model nahi aa saka ({e}) — chhota model "
                            "use hoga, translation kamzor ho sakti hai.")
                    _base_model = _get_model()
    return _base_model


def _load_wav_16k_mono(path):
    """16kHz mono wav -> float32 numpy array (-1..1)."""
    with wave.open(path, "rb") as w:
        if w.getframerate() != 16000 or w.getnchannels() != 1:
            raise RuntimeError("WAV 16kHz mono hona chahiye: " + path)
        raw = w.readframes(w.getnframes())
    return np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0


def detect_language(wav_path, log=None):
    """Pehle 30 sec se video ki language detect karo -> (code, probability).

    code: 'en', 'hi', 'ur', ... (Whisper ke language codes).
    """
    with _lock:
        model = _get_model()
    audio = _load_wav_16k_mono(wav_path)
    sample = audio[:30 * 16000] if len(audio) > 30 * 16000 else audio
    segments, info = model.transcribe(sample, beam_size=1,
                                      vad_filter=False)
    try:
        next(segments)
    except StopIteration:
        pass
    lang = (getattr(info, "language", None) or "en").lower()
    prob = float(getattr(info, "language_probability", 0) or 0)
    if log:
        name = LANG_NAMES.get(lang, lang)
        log(f"Video ki language: {name} (confidence {int(prob * 100)}%)")
    return lang, prob


def transcribe_wav(wav_path, log=None, language=None, to_english=False):
    """wav file -> [(start_sec, end_sec, text)].

    language: 'en'/'hi'/'ur'/... ya None (auto-detect).
    to_english=True: usi zaban se English me translate karke subtitles
    (Hindi video -> English subtitles).
    """
    if log:
        log("AI subtitles bana raha hai...")
    # translate ke liye bara (base) model — tiny ki Hindi->English
    # translation kamzor hoti hai. _get_translate_model apna lock
    # khud sambhalta hai; inference thread-safe hai.
    use_base = to_english
    if use_base:
        model = _get_translate_model(log)
    else:
        # sirf model loading lock hoti hai; inference (ctranslate2)
        # thread-safe hai aur parallel workers me ek sath chalti hai
        with _lock:
            model = _get_model()
    audio = _load_wav_16k_mono(wav_path)
    task = "translate" if to_english else "transcribe"
    if log and to_english:
        log("English subtitles bana raha hai (translate)...")
    segments, _info = model.transcribe(
        audio, language=language, task=task, beam_size=5, vad_filter=True)
    out = []
    for s in segments:
        text = (s.text or "").strip()
        if text:
            out.append((float(s.start), float(s.end), text))
    if log:
        log(f"AI ne {len(out)} subtitle lines banayeen.")
    return out
