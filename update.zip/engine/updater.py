"""GitHub se automatic updates.

Kaam karne ka tareeqa:
  1. check() — GitHub repo ki version.txt padhta hai, local version.txt se
     compare karta hai. Nayi version ho to True.
  2. apply_update() — update.zip download karke app folder par extract karta
     hai. models/, venv/ aur user ki cheezon ko haath nahi lagata.

Repo: https://github.com/Fury-67/clipcraze-clipper (public)
"""
import os
import shutil
import tempfile
import urllib.request
import zipfile

REPO = "Fury-67/clipcraze-clipper"
BRANCH = "main"
# raw.githubusercontent.com ka CDN purani files de sakta hai (stale cache),
# is liye GitHub API se lete hain (Accept: vnd.github.raw = seedhi file bytes)
API_BASE = f"https://api.github.com/repos/{REPO}/contents"
VERSION_URL = f"{API_BASE}/version.txt"
ZIP_URL = f"{API_BASE}/update.zip"
HEADERS = {"User-Agent": "ClipCraze-Clipper",
           "Accept": "application/vnd.github.raw"}

# update me ye kabhi overwrite nahi honge (user ka data / heavy files)
PROTECTED = {"models", "venv", ".venv", "sources", "__pycache__"}


def app_dir():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def local_version():
    p = os.path.join(app_dir(), "version.txt")
    try:
        with open(p, encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return "0.0.0"


def _urlopen_retry(req, timeout, tries=3):
    """Network blip ho to 3 dafa try karo."""
    last = None
    for _ in range(tries):
        try:
            return urllib.request.urlopen(req, timeout=timeout)
        except Exception as e:
            last = e
    raise last


def remote_version(timeout=20):
    req = urllib.request.Request(VERSION_URL, headers=HEADERS)
    with _urlopen_retry(req, timeout) as r:
        return r.read().decode("utf-8").strip()


def _vtuple(v):
    parts = []
    for x in str(v).strip().split("."):
        try:
            parts.append(int(x))
        except ValueError:
            parts.append(0)
    return tuple(parts)


def check():
    """(available: bool, remote_ver: str|None, err: str|None)"""
    lv = local_version()
    try:
        rv = remote_version()
    except Exception as e:
        return False, None, f"GitHub se rabta nahi ho saka: {e}"
    if not rv:
        return False, None, "GitHub se version nahi mil saki."
    if _vtuple(rv) > _vtuple(lv):
        return True, rv, None
    return False, rv, None


def _download(url, dest, cb_prog=None, timeout=120):
    req = urllib.request.Request(url, headers=HEADERS)
    with _urlopen_retry(req, timeout) as r:
        total = int(r.headers.get("Content-Length") or 0)
        got = 0
        with open(dest, "wb") as f:
            while True:
                chunk = r.read(65536)
                if not chunk:
                    break
                f.write(chunk)
                got += len(chunk)
                if cb_prog and total:
                    cb_prog(got / total)


def apply_update(cb_log=None, cb_prog=None):
    """Nayi version download + install. Returns new version string."""
    def log(m):
        if cb_log:
            cb_log(m)

    adir = app_dir()
    lv = local_version()
    log(f"Update download ho raha hai (v{lv} -> ...)...")
    tmp = tempfile.mkdtemp(prefix="clipcraze_upd_")
    zpath = os.path.join(tmp, "update.zip")
    try:
        _download(ZIP_URL, zpath,
                  cb_prog=lambda f: cb_prog(f) if cb_prog else None)
        log("Download complete — files install ho rahi hain...")
        xdir = os.path.join(tmp, "x")
        with zipfile.ZipFile(zpath) as z:
            z.extractall(xdir)
        # zip ke andar files seedhi hain (app.py, engine/, ...), koi
        # extra top-level folder nahi — phir bhi handle kar lo
        entries = os.listdir(xdir)
        if len(entries) == 1 and os.path.isdir(os.path.join(xdir,
                                                            entries[0])):
            xdir = os.path.join(xdir, entries[0])
        count = 0
        for entry in os.listdir(xdir):
            if entry in PROTECTED:
                continue
            s = os.path.join(xdir, entry)
            d = os.path.join(adir, entry)
            if os.path.isdir(s):
                if os.path.exists(d):
                    shutil.rmtree(d, ignore_errors=True)
                shutil.copytree(s, d)
            else:
                shutil.copy2(s, d)
            count += 1
        # purana bytecode cache hatao taake naya code load ho
        for root, dirs, _files in os.walk(adir):
            if "__pycache__" in dirs:
                shutil.rmtree(os.path.join(root, "__pycache__"),
                              ignore_errors=True)
        # version.txt update.zip me hoti hai; na ho to remote se lo
        try:
            rv = remote_version()
            with open(os.path.join(adir, "version.txt"), "w",
                      encoding="utf-8") as f:
                f.write(rv)
        except Exception:
            rv = local_version()
        log(f"Update install ho gaya! v{lv} -> v{rv} 🎉")
        log("App restart karo taake nayi cheezen load hon.")
        return rv
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
