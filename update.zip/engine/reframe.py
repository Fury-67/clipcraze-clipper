"""Face-aware vertical reframing (proven v6 logic, function form me).

Fixed center-crop chehre kaat deta hai — is liye camera chehron ko
follow karta hai:
  0 faces        -> wahin ruko
  1 face         -> usi ko frame karo
  2 faces qareeb -> darmiyan (dono nazar aayen)
  2 faces door   -> pichle target ke qareeb wala (continuity), har ~6s me
                    khamosh lamhe me dusre chehre pe cut (dono ko time mile)
"""
import glob
import os
import subprocess
import tempfile
import shutil

import cv2
import numpy as np

SAMPLE_FPS = 4.0
SEG_S = 6.0  # door chehron me itne sec baad cut


def probe_wh(src):
    cap = cv2.VideoCapture(src)
    if not cap.isOpened():
        raise RuntimeError("Video khul nahi rahi: " + src)
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    cap.release()
    return w, h


def compute_trajectory(src, start, dur, model_path, ffmpeg, log=None):
    """(W, H, crop_w, crop_h, x_at) deta hai. x_at(t) -> crop center-x (0..W)."""
    W, H = probe_wh(src)
    crop_h = H
    crop_w = int(H * 9 / 16) & ~1  # even width (libx264/yuv420p ke liye)
    if crop_w > W:
        crop_w = W & ~1
    close_px = W * 340.0 / 1280.0

    tmpd = tempfile.mkdtemp(prefix="reframe_")
    try:
        # audio energy (khamosh lamhon pe cut ke liye)
        aud_raw = os.path.join(tmpd, "aud.raw")
        subprocess.run(
            [ffmpeg, "-y", "-v", "error",
             "-ss", str(start), "-t", str(dur), "-i", src,
             "-ac", "1", "-ar", "8000", "-f", "s16le", aud_raw],
            check=True)
        pcm = np.fromfile(aud_raw, dtype=np.int16).astype(np.float32) / 32768.0
        win = 800
        n_win = max(1, len(pcm) // win)
        energy = np.array([np.sqrt(np.mean(pcm[k * win:(k + 1) * win] ** 2))
                           for k in range(n_win)])
        e_med = float(np.median(energy)) + 1e-6

        def quietest(t, span=1.5):
            lo = max(0, int((t - span) * 10))
            hi = min(n_win - 3, int((t + span) * 10))
            if hi <= lo:
                return t
            sums = [energy[k] + energy[k + 1] + energy[k + 2]
                    for k in range(lo, hi)]
            return (lo + int(np.argmin(sums)) + 1) * 0.1

        # sample + face detect
        subprocess.run(
            [ffmpeg, "-y", "-v", "error",
             "-ss", str(start), "-i", src, "-t", str(dur),
             "-vf", f"fps={SAMPLE_FPS}", os.path.join(tmpd, "s_%03d.jpg")],
            check=True)
        jpgs = sorted(glob.glob(os.path.join(tmpd, "s_*.jpg")))

        det = cv2.FaceDetectorYN_create(model_path, "", (W, H),
                                        score_threshold=0.4)
        face_x = []
        for jp in jpgs:
            frame = cv2.imread(jp)
            det.setInputSize((frame.shape[1], frame.shape[0]))
            _, faces = det.detect(frame)
            xs = []
            if faces is not None:
                for f in sorted(faces, key=lambda f: f[2] * f[3],
                                reverse=True)[:2]:
                    if f[2] >= 50:
                        xs.append(float(f[0] + f[2] / 2))
            face_x.append(sorted(xs))

        # camera target per sample
        cuts = []
        t = SEG_S
        while t < dur - 2.0:
            cuts.append(quietest(t))
            t += SEG_S

        traj = []
        prev = W / 2
        cut_i = 0
        for i, xs in enumerate(face_x):
            t = i / SAMPLE_FPS
            if len(xs) == 0:
                target = prev
            elif len(xs) == 1:
                target = xs[0]
            elif max(xs) - min(xs) <= close_px:
                target = sum(xs) / len(xs)
            else:
                if cut_i < len(cuts) and t >= cuts[cut_i]:
                    target = max(xs, key=lambda x: abs(x - prev))
                    cut_i += 1
                else:
                    target = min(xs, key=lambda x: abs(x - prev))
            traj.append(target)
            prev = target

        # EMA smoothing
        alpha, e, sm = 0.30, (traj[0] if traj else W / 2), []
        for x in traj:
            e = alpha * x + (1 - alpha) * e
            sm.append(e)
        lo, hi = crop_w / 2, W - crop_w / 2
        if hi < lo:
            lo = hi = W / 2
        sm = [min(max(v, lo), hi) for v in sm]

        def x_at(t):
            if not sm:
                return W / 2
            pos = t * SAMPLE_FPS
            i0 = int(pos)
            if i0 >= len(sm) - 1:
                return sm[-1]
            frac = pos - i0
            return sm[i0] * (1 - frac) + sm[i0 + 1] * frac

        if log:
            log(f"Reframe ready ({W}x{H}, crop {crop_w}x{crop_h})")
        return W, H, crop_w, crop_h, x_at
    finally:
        shutil.rmtree(tmpd, ignore_errors=True)
