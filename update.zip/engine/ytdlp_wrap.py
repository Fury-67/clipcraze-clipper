"""yt-dlp Python API wrapper: info, video download, captions.

Pehle normal client se HD download ki koshish hoti hai. Agar YouTube
bot-check lagaye to android player client pe fallback (phir 360p milta hai).
"""
import glob
import os

import yt_dlp


def _base_params():
    return {
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
    }


def get_info(url):
    """Video ka title, duration aur most-replayed heatmap nikalta hai."""
    params = _base_params()
    try:
        with yt_dlp.YoutubeDL(params) as ydl:
            return ydl.extract_info(url, download=False)
    except Exception:
        # fallback: android client (bot-check bypass, 360p)
        params["extractor_args"] = {"youtube": {"player_client": ["android"]}}
        with yt_dlp.YoutubeDL(params) as ydl:
            return ydl.extract_info(url, download=False)


def download(url, out_path, quality="720p", progress_cb=None):
    """Video download karta hai. progress_cb(frac 0..1) GUI ke liye."""

    def hook(d):
        if d.get("status") == "downloading" and progress_cb:
            total = d.get("total_bytes") or d.get("total_bytes_estimate")
            if total:
                progress_cb(min(1.0, d.get("downloaded_bytes", 0) / total))

    h_map = {"720p": "720", "1080p": "1080", "2K": "1440", "4K": "2160"}
    max_h = h_map.get(quality, "720")
    params = _base_params()
    params.update(
        {
            "format": f"bv*[height<={max_h}]+ba/b[height<={max_h}]/b",
            "merge_output_format": "mp4",
            "outtmpl": out_path,
            "progress_hooks": [hook],
        }
    )
    try:
        with yt_dlp.YoutubeDL(params) as ydl:
            ydl.download([url])
    except Exception:
        params["extractor_args"] = {"youtube": {"player_client": ["android"]}}
        with yt_dlp.YoutubeDL(params) as ydl:
            ydl.download([url])
    if not os.path.exists(out_path):
        # yt-dlp ne extension lagayi ho to dhoondo
        cands = glob.glob(out_path + ".*")
        if cands:
            os.replace(cands[0], out_path)
    if not os.path.exists(out_path):
        raise RuntimeError("Download fail ho gaya.")


def download_subs(url, tmpdir):
    """English auto/manual captions ka .vtt file dhoond kar laata hai (ya None)."""
    outtmpl = os.path.join(tmpdir, "sub")
    params = _base_params()
    params.update(
        {
            "writesubtitles": True,
            "writeautomaticsub": True,
            "subtitleslangs": ["en.*"],
            "subtitlesformat": "vtt",
            "skip_download": True,
            "outtmpl": outtmpl,
        }
    )
    try:
        with yt_dlp.YoutubeDL(params) as ydl:
            ydl.download([url])
    except Exception:
        try:
            params["extractor_args"] = {"youtube": {"player_client": ["android"]}}
            with yt_dlp.YoutubeDL(params) as ydl:
                ydl.download([url])
        except Exception:
            return None
    vtts = sorted(glob.glob(os.path.join(tmpdir, "sub*.vtt")))
    return vtts[0] if vtts else None
