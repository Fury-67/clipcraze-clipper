"""Most-replayed heatmap se top clip points nikalta hai.

Har peak ka score (0..1) uski heatmap intensity hoti hai — jitna zyada
replay hua, utna zyada score. Auto clip-duration isi score se tay hoti hai:
zyada important moment = lamba clip.
"""


def _find_peaks_scored(heatmap, n, min_gap):
    """[(score 0..1, start_time)] — score normalized heat intensity."""
    if not heatmap:
        return []
    pts = sorted(heatmap, key=lambda p: p["start_time"])
    vals = [p["value"] for p in pts]
    mx = max(vals) or 1
    norm = [v / mx for v in vals]
    cands = []
    for i in range(1, len(norm) - 1):
        if norm[i] >= norm[i - 1] and norm[i] >= norm[i + 1] and norm[i] > 0.35:
            cands.append((norm[i], pts[i]["start_time"]))
    cands.sort(reverse=True)
    picked = []
    for score, t in cands:
        if all(abs(t - p[1]) >= min_gap for p in picked):
            picked.append((score, t))
        if len(picked) == n:
            break
    return sorted(picked, key=lambda x: x[1])


def find_peaks(heatmap, n, min_gap):
    """heatmap: [{start_time, end_time, value}]. Top-n peak start_times deta hai."""
    return [t for _, t in _find_peaks_scored(heatmap, n, min_gap)]


def pick_points(heatmap, n, clip_len, duration):
    """Peaks uthao; kam paren to baqi evenly-spaced points se bhar do."""
    peaks = find_peaks(heatmap, n, clip_len)
    if len(peaks) < n and duration and duration > 0:
        # kitne clips fit ho sakte hain (overlap nahi hona chahiye)
        max_fit = max(1, int(duration // clip_len))
        want = min(n, max_fit)
        if len(peaks) < want:
            step = duration / (want + 1)
            for i in range(want):
                t = step * (i + 1)
                if all(abs(t - p) >= clip_len for p in peaks):
                    peaks.append(t)
                if len(peaks) >= want:
                    break
    return sorted(peaks)[:n]


def pick_points_scored(heatmap, n, clip_len, duration):
    """[(time, score 0..1)] — peaks apne score ke sath;
    kam paren to evenly-spaced fallback (score 0.5)."""
    scored = _find_peaks_scored(heatmap, n, clip_len)
    times = [t for _, t in scored]
    if len(scored) < n and duration and duration > 0:
        max_fit = max(1, int(duration // clip_len))
        want = min(n, max_fit)
        if len(scored) < want:
            step = duration / (want + 1)
            for i in range(want):
                t = step * (i + 1)
                if all(abs(t - p) >= clip_len for p in times):
                    scored.append((0.5, t))
                    times.append(t)
                if len(scored) >= want:
                    break
    scored = sorted(scored, key=lambda x: x[1])[:n]
    return [(t, s) for s, t in scored]


def score_to_duration(score):
    """Importance score (0..1) -> clip length 15..60 sec (5 ke multiple me)."""
    d = 15 + max(0.0, min(1.0, score)) * 45
    d = int(round(d / 5) * 5)
    return max(15, min(60, d))
