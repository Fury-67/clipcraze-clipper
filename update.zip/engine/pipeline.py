"""Poora pipeline: link -> download -> peaks -> har clip: reframe + subs + hook + CTA.

Progress GUI tak cb() ke zariye pahunchti hai:
    cb("log", "koi message")
    cb("progress", 0.0-1.0, "status text")

Speed ke liye clips parallel bante hain (ThreadPoolExecutor).
"""
import os
import re
import shutil
import subprocess
import tempfile
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

import numpy as np

import cv2

from . import ffmpeg_bin, ytdlp_wrap, peaks, subs, reframe, textdraw, transcribe

FPS_OUT = 30

# Quality option -> asli output size (vertical Short)
QUALITY_DIMS = {
    # Vertical 9:16 — Shorts / TikTok / Reels
    "9:16": {"720p": (720, 1280), "1080p": (1080, 1920),
             "2K": (1440, 2560), "4K": (2160, 3840)},
    # Landscape 16:9 — normal YouTube videos
    "16:9": {"720p": (1280, 720), "1080p": (1920, 1080),
             "2K": (2560, 1440), "4K": (3840, 2160)},
}


def _esc_filter_path(p):
    """Windows/Unix path ko ffmpeg filter me safe banana."""
    return p.replace("\\", "/").replace("'", r"'\''").replace(":", r"\:")


def _sanitize(name):
    name = re.sub(r"[^\w\- ]", "", name or "video").strip()[:40]
    return name or "video"


def _ass_dialogue_texts(ass_path):
    """ASS file se subtitle lines ka khaalis text nikalo (caption ke liye)."""
    texts = []
    try:
        with open(ass_path, encoding="utf-8") as f:
            for line in f:
                if line.startswith("Dialogue:"):
                    parts = line.split(",", 9)
                    if len(parts) == 10:
                        t = re.sub(r"\{[^}]*\}", "",
                                   parts[9]).replace("\\N", " ").strip()
                        if t:
                            texts.append(t)
    except OSError:
        pass
    return texts


def _smart_caption(texts, video_title):
    """Clip ke transcript se YouTube title + caption banao.

    Returns (title, caption). Transcript na ho to generic fallback.
    """
    clean = [t.strip() for t in texts if t and t.strip()]
    vt = (video_title or "Best Moment").strip()
    if not clean:
        return (f"{vt} 🔥 #Shorts",
                f"{vt} ka best moment! 🔥\n\n#Shorts #viral #ClipCrazeShorts")
    # hook: sab se lambi line (sab se zyada content wali)
    hook = max(clean, key=len).strip()
    if len(hook) > 80:
        hook = hook[:77].rsplit(" ", 1)[0] + "..."
    title = f"{hook} 🔥 #Shorts"
    desc = " ".join(clean[:6])
    if len(desc) > 250:
        desc = desc[:247].rsplit(" ", 1)[0] + "..."
    caption = f"{desc}\n\n#Shorts #viral #ClipCrazeShorts"
    return title, caption


def _run_clip(src, start, dur, out_path, ass_path, hook_text, with_cta,
              model_path, ffmpeg, out_w=720, out_h=1280, aspect="9:16",
              watermark="", log=None, frame_cb=None, x264_threads="2"):
    W, H = reframe.probe_wh(src)

    if aspect == "16:9":
        # landscape output: poora frame, face-tracking ki zaroorat nahi.
        # source 16:9 na ho to center se 16:9 crop.
        target = 16 / 9
        src_ar = W / H if H else target
        if abs(src_ar - target) < 0.02:
            cw, ch = W, H
        elif src_ar > target:
            cw, ch = int(H * target), H  # sides kato
        else:
            cw, ch = W, int(W / target)  # upar-neeche kato
        cw -= cw % 2
        ch -= ch % 2
        x_at = None
        if log:
            log("Landscape 16:9 — full frame (no crop).")
    elif H > W:
        # pehle se vertical: seedha scale, koi crop nahi
        cw, ch = W, H
        x_at = None
        if log:
            log("Source vertical hai — direct convert ho raha hai.")
    else:
        W2, H2, cw, ch, x_at = reframe.compute_trajectory(
            src, start, dur, model_path, ffmpeg, log)
        if log:
            log("Face tracking done ✓ — rendering shuru...")

    # resize quality: chhota kar rahe hain to INTER_AREA (best), warna CUBIC
    interp = cv2.INTER_AREA if cw > out_w else cv2.INTER_CUBIC
    need_resize = (cw, ch) != (out_w, out_h)

    vf = f"ass='{_esc_filter_path(ass_path)}'" if ass_path else None

    dec = subprocess.Popen(
        [ffmpeg, "-v", "error",
         "-ss", str(start), "-t", str(dur), "-i", src,
         "-vf", f"fps={FPS_OUT}",
         "-f", "rawvideo", "-pix_fmt", "bgr24", "-"],
        stdout=subprocess.PIPE)
    cmd = [ffmpeg, "-y", "-v", "error",
           "-f", "rawvideo", "-pix_fmt", "bgr24",
           "-s", f"{out_w}x{out_h}", "-r", str(FPS_OUT), "-i", "-",
           "-ss", str(start), "-t", str(dur), "-i", src]
    if vf:
        cmd += ["-vf", vf]
    # thread budget: workers x x264_threads ~= cpu_count (oversubscription
    # slowdown fix). x264_threads run_pipeline se aata hai.
    enc_threads = str(max(1, int(x264_threads or 2)))
    # ATOMIC OUTPUT: pehle temp file me encode karo; kamyab ho to hi
    # final naam do. Beech me app band ho to adhuri file final naam se
    # kabhi nahi rahegi (corrupt file wala masla khatam).
    # NOTE: naam .mp4 par KHATAM hona chahiye warna FFmpeg output format
    # pehchan nahi pata (".mp4.part" -> "Unable to choose an output
    # format" error). Is liye ".part.mp4" istemal hota hai.
    part_path = out_path + ".part.mp4"
    cmd += ["-map", "0:v", "-map", "1:a?",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
            "-threads", enc_threads,
            "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "128k",
            "-movflags", "+faststart", "-shortest", part_path]
    enc = subprocess.Popen(cmd, stdin=subprocess.PIPE)

    cta_from = dur - 3.0 if with_cta else None
    # SPEED: static overlays (hook/watermark/CTA) ek dafa pre-render.
    # Har frame par PIL + full-frame copies nahi — sirf sasta numpy blend.
    # Layout bilkul wahi, quality me zero farq.
    hook_ov = (textdraw.make_hook_overlay(out_w, out_h, hook_text)
               if hook_text else None)
    wm_ov = (textdraw.make_watermark_overlay(out_w, out_h, watermark)
             if watermark else None)
    cta_frame = textdraw.make_cta_frame(out_w, out_h) if with_cta else None
    n_frames = int(dur * FPS_OUT)
    frame_size = W * H * 3
    try:
        for n in range(n_frames):
            data = dec.stdout.read(frame_size)
            if len(data) < frame_size:
                break
            frame = np.frombuffer(data, dtype=np.uint8).reshape(H, W, 3)
            if x_at is not None:
                cx = x_at(n / FPS_OUT)
                x0 = min(max(int(round(cx - cw / 2)), 0), W - cw)
                crop = frame[0:ch, x0:x0 + cw]
            elif (cw, ch) != (W, H):
                # fixed center crop (16:9 landscape)
                x0 = (W - cw) // 2
                y0 = (H - ch) // 2
                crop = frame[y0:y0 + ch, x0:x0 + cw]
            else:
                crop = frame
            if need_resize:
                crop = cv2.resize(crop, (out_w, out_h), interpolation=interp)
            t = n / FPS_OUT
            # Watermark sab se pehle (hook/CTA ke neeche rahega)
            if wm_ov is not None:
                textdraw.blend_overlay(crop, wm_ov)
            elif watermark:
                crop = textdraw.draw_watermark(crop, watermark)
            # Hook/CTA: pre-rendered overlay (tez), warna purana per-frame
            if hook_text and t < 2.5:
                if hook_ov is not None:
                    textdraw.blend_overlay(crop, hook_ov)
                else:
                    crop = textdraw.draw_hook(crop, hook_text)
            if cta_from is not None and t >= cta_from:
                if cta_frame is not None:
                    np.copyto(crop, cta_frame)
                else:
                    crop = textdraw.draw_cta(crop)
            enc.stdin.write(crop.tobytes())
            if frame_cb and n % 60 == 0:
                frame_cb(n / n_frames)
    finally:
        try:
            enc.stdin.close()
        except Exception:
            pass
        dec.wait()
        enc.wait()
    if enc.returncode != 0:
        try:
            os.remove(part_path)
        except OSError:
            pass
        raise RuntimeError("Clip encode fail ho gaya.")
    # kamyab: .part -> final naam (atomic rename)
    os.replace(part_path, out_path)
    return out_path


def run_pipeline(url, out_dir, num_clips=10, clip_len=30, quality="720p",
                 aspect="9:16",
                 subtitle_mode="ai", subtitle_style="classic",
                 subtitle_lang="auto",
                 hook_text="WAIT FOR IT!", with_cta=True,
                 watermark="",
                 manual_segments=None, src_file=None,
                 cb=None):
    """subtitle_mode: 'ai' (Whisper auto), 'youtube' (YT captions, warna AI),
    'off'. subtitle_style: subs.STYLES ki key.
    subtitle_lang: 'auto' (video ki zaban me subtitles) ya 'en'
    (AI translate karke English subtitles).
    aspect: '9:16' (Shorts/TikTok/Reels, face-aware vertical crop) ya
    '16:9' (normal YouTube video, full frame).
    clip_len: int (sec) ya 'auto' — auto me har clip ki length uski
    importance (heatmap score) se 15..60s khud tay hoti hai.
    watermark: text (masalan '@ClipCrazeShorts') ya '' (off).
    manual_segments: [(start_sec, end_sec), ...] — user ke khud chune hue
    moments; diya ho to heatmap/AI selection skip ho jata hai.
    src_file: pehle se download shuda video ka path (dobara download skip).
    Returns: [(mp4_path, title, caption), ...] — har clip ka
    transcript-based smart YouTube title + caption."""
    def log(msg):
        if cb:
            cb("log", msg)

    def prog(frac, msg=""):
        if cb:
            cb("progress", max(0.0, min(1.0, frac)), msg)

    ffmpeg = ffmpeg_bin.get_ffmpeg()
    model_path = os.path.join(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__))), "models", "face_yunet.onnx")
    if not os.path.exists(model_path):
        raise RuntimeError("Face model nahi mila: " + model_path)

    os.makedirs(out_dir, exist_ok=True)
    # pichli dafa ki adhuri .part.mp4 files hatao
    for _f in os.listdir(out_dir):
        if _f.endswith(".part.mp4") or _f.endswith(".mp4.part"):
            try:
                os.remove(os.path.join(out_dir, _f))
            except OSError:
                pass
    tmp = tempfile.mkdtemp(prefix="clipper_")
    dims = QUALITY_DIMS.get(aspect, QUALITY_DIMS["9:16"])
    out_w, out_h = dims.get(quality, (720, 1280))
    try:
        log("Video ki info le raha hun...")
        prog(0.02, "Info...")
        info = ytdlp_wrap.get_info(url)
        base_title = _sanitize(info.get("title"))
        duration = info.get("duration") or 0
        heatmap = info.get("heatmap") or []
        log(f"Title: {info.get('title', '?')}")
        log(f"Duration: {int(duration // 60)}:{int(duration % 60):02d} | "
            f"Format: {aspect} | "
            f"Heatmap points: {len(heatmap)} | Output: {out_w}x{out_h}")

        auto_len = (clip_len == "auto")
        max_len = 60 if auto_len else clip_len
        manual = [(float(s), float(e)) for s, e in (manual_segments or [])
                  if float(e) > float(s)]
        if manual:
            # user ke khud chune hue moments — heatmap skip
            points = [s for s, _ in manual]
            durations = [e - s for s, e in manual]
            num_clips = len(points)
            is_manual = True
            log(f"Manual mode: {len(points)} segments "
                f"({', '.join(f'{int(s//60)}:{int(s%60):02d}' for s, _ in manual)})")
        else:
            is_manual = False
            if duration and num_clips * max_len > duration:
                num_clips = max(1, int(duration // max_len))
                log(f"Video chhoti hai — {num_clips} clips banenge.")

            if auto_len:
                # har peak ki importance (score) se uski length: 15..60s
                scored = peaks.pick_points_scored(heatmap, num_clips, 60,
                                                  duration)
                points = [t for t, _ in scored]
                durations = [peaks.score_to_duration(s) for _, s in scored]
            else:
                points = peaks.pick_points(heatmap, num_clips, clip_len,
                                           duration)
                durations = [clip_len] * len(points)
        if not points:
            raise RuntimeError("Koi clip point nahi mila.")
        if heatmap:
            log(f"Most-replayed points mil gaye: {len(points)}" +
                (" (auto length 🎯)" if auto_len else ""))
        else:
            log("Heatmap nahi mila — evenly spaced clips bana raha hun.")
        num_clips = len(points)

        log("Video download ho rahi hai...")
        src = os.path.join(tmp, "src.mp4")

        def dl_cb(frac):
            prog(0.02 + 0.23 * frac, f"Download {int(frac * 100)}%")

        if src_file and os.path.isfile(src_file):
            # manual mode me pehle se download shuda video — dobara nahi
            src = src_file
            log(f"Pehle se download shuda video use ho rahi hai "
                f"({os.path.getsize(src) // 1024 // 1024} MB) — "
                f"download skip ⏩")
            prog(0.25, "Video ready...")
        else:
            ytdlp_wrap.download(url, src, quality, dl_cb)
            log(f"Download complete ({os.path.getsize(src) // 1024 // 1024} MB)")

        # video ki language ek dafa detect karo (Hindi/Urdu/etc.)
        # taake subtitles usi zaban me banen
        lang = None
        if subtitle_mode in ("ai", "youtube"):
            try:
                lang_wav = os.path.join(tmp, "langdetect.wav")
                subprocess.run(
                    [ffmpeg, "-y", "-v", "error",
                     "-t", "30", "-i", src,
                     "-ar", "16000", "-ac", "1", "-f", "wav", lang_wav],
                    check=True)
                lang, prob = transcribe.detect_language(lang_wav, log)
                if prob < 0.5:
                    log("Language clear nahi — auto mode me rahega.")
                    lang = None
            except Exception as e:
                log(f"Language detect nahi ho saki ({e}) — auto mode.")
                lang = None

        vtt = None
        if subtitle_mode == "youtube":
            log("YouTube captions download kar raha hun...")
            vtt = ytdlp_wrap.download_subs(url, tmp)
            log("YouTube captions mil gaye." if vtt else
                "YouTube captions nahi mile — AI se banaunga.")

        # parallel clips = bohot tez ⚡
        cpu_n = os.cpu_count() or 4
        workers = min(4, max(2, cpu_n // 2))
        # thread budget: workers x x264_threads ~= cpu_count, taake CPU
        # oversubscribe na ho (pehle 4 workers x 4 threads = thrashing).
        x264_threads = str(max(1, cpu_n // workers))
        log(f"{workers} clips ek sath ban rahe hain ⚡")
        done_n = [0]
        done_lock = threading.Lock()

        def make_one(i, peak, dur):
            # manual mode: peak hi asal start hai; auto me 5s pehle se shuru
            start = peak if is_manual else max(0.0, peak - 5)
            if duration and start + dur > duration:
                start = max(0.0, duration - dur)
            out = os.path.join(out_dir, f"{base_title}-clip{i}.mp4")
            log(f"Clip {i}/{num_clips} ({dur}s) ban rahi hai...")
            ass_path = None
            clip_texts = []  # caption ke liye transcript
            if subtitle_mode in ("ai", "youtube"):
                ass_path = os.path.join(tmp, f"clip{i}.ass")
                # CTA card (aakhri 3s) par subtitles nahi dikhne chahiye
                sub_dur = dur - 3 if with_cta else dur
                n = 0
                if subtitle_mode == "youtube" and vtt:
                    n = subs.vtt_to_ass(vtt, ass_path, offset=start,
                                        clip_len=sub_dur,
                                        style=subtitle_style,
                                        play_w=out_w, play_h=out_h)
                    if n > 0:
                        clip_texts = _ass_dialogue_texts(ass_path)
                if n == 0:
                    # AI transcribe (khud audio sun kar subtitles)
                    wav = os.path.join(tmp, f"clip{i}.wav")
                    subprocess.run(
                        [ffmpeg, "-y", "-v", "error",
                         "-ss", str(start), "-t", str(dur), "-i", src,
                         "-ar", "16000", "-ac", "1", "-f", "wav", wav],
                        check=True)
                    segs = transcribe.transcribe_wav(
                        wav, log, language=lang,
                        to_english=(subtitle_lang == "en"))
                    clip_texts = [t for _, _, t in segs]
                    n = subs.segments_to_ass(segs, ass_path,
                                             style=subtitle_style,
                                             clip_len=sub_dur,
                                             play_w=out_w, play_h=out_h)
                if n == 0:
                    ass_path = None
                    log(f"Clip {i}: koi dialogue nahi mila.")
                else:
                    log(f"Clip {i}: subtitles ready ({n} lines).")

            def fcb(frac):
                with done_lock:
                    d = done_n[0]
                base = 0.25 + 0.75 * (d / num_clips)
                prog(base + 0.75 * frac / num_clips,
                     f"Clip {i}/{num_clips} ({dur}s)...")

            _run_clip(src, start, dur, out, ass_path, hook_text,
                      with_cta, model_path, ffmpeg, out_w, out_h,
                      aspect=aspect, watermark=watermark,
                      x264_threads=x264_threads,
                      log=lambda m: log(f"Clip {i}: {m}"), frame_cb=fcb)
            with done_lock:
                done_n[0] += 1
            log(f"Clip {i} ready ✅")
            title, caption = _smart_caption(clip_texts,
                                            info.get("title", "Best Moment"))
            return (out, title, caption)

        made = []
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = {ex.submit(make_one, i, pk, dr): i
                    for i, (pk, dr) in enumerate(zip(points, durations), 1)}
            results = {}
            for fut in as_completed(futs):
                results[futs[fut]] = fut.result()
        made = [results[i] for i in sorted(results)]

        # suggested titles/captions file (copy-paste ke liye)
        info_txt = os.path.join(out_dir, "clips_info.txt")
        with open(info_txt, "w", encoding="utf-8") as f:
            for path, title, caption in made:
                f.write(f"=== {os.path.basename(path)} ===\n")
                f.write(f"Title: {title}\n")
                f.write(f"Caption:\n{caption}\n\n")

        prog(1.0, "Done!")
        log(f"\nHo gaya! 🎉 {len(made)} clips: {out_dir}")
        return made
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
