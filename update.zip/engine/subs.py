"""VTT captions -> styled ASS subtitles (bohat sare styles!).

Ahem: timestamps ko segment ke hisaab se shift kiya jata hai (offset),
taake captions clip ke sath bilkul sync rahen.

Colors ASS format me hain: &HAABBGGRR
"""
import re

# key -> (GUI naam, style dict)
STYLES = {
    "classic": ("Classic White", dict(
        fontsize=30, primary="&H00FFFFFF", outline_c="&H80000000",
        back="&H80000000", bold=-1, border_style=1, outline=1, shadow=1)),
    "yellow": ("Yellow Pop", dict(
        fontsize=32, primary="&H0000FFFF", outline_c="&H80000000",
        back="&H80000000", bold=-1, border_style=1, outline=2, shadow=1)),
    "neon": ("Neon Cyan", dict(
        fontsize=30, primary="&H00FFFF00", outline_c="&H80180060",
        back="&H80000000", bold=-1, border_style=1, outline=1, shadow=2)),
    "meme": ("Meme Bold", dict(
        fontsize=42, primary="&H00FFFFFF", outline_c="&HFF000000",
        back="&H80000000", bold=-1, border_style=1, outline=3, shadow=2)),
    "minimal": ("Minimal", dict(
        fontsize=24, primary="&H00D8D8D8", outline_c="&H80000000",
        back="&H80000000", bold=0, border_style=1, outline=0, shadow=1)),
    "blackbox": ("Black Box", dict(
        fontsize=30, primary="&H00FFFFFF", outline_c="&H80000000",
        back="&H90000000", bold=-1, border_style=3, outline=1, shadow=0)),
    "red": ("Red Hot", dict(
        fontsize=32, primary="&H000000FF", outline_c="&H80000000",
        back="&H80000000", bold=-1, border_style=1, outline=2, shadow=1)),
    "green": ("Green Glow", dict(
        fontsize=30, primary="&H0000FF00", outline_c="&H80000000",
        back="&H80000000", bold=-1, border_style=1, outline=1, shadow=2)),
}

STYLE_GUI_NAMES = [v[0] for v in STYLES.values()]
GUI_TO_KEY = {v[0]: k for k, v in STYLES.items()}


def _style_line(key, scale=1.0):
    s = dict(STYLES.get(key, STYLES["classic"])[1])
    s["fontsize"] = int(round(s["fontsize"] * scale))
    # outline/shadow bhi resolution ke sath barhao (0 wale 0 hi rahen)
    for k in ("outline", "shadow"):
        s[k] = max(1, int(round(s[k] * scale))) if s[k] else 0
    return (
        "Style: Cap,DejaVu Sans,{fontsize},{primary},&H000019FF,"
        "{outline_c},{back},{bold},0,0,0,100,100,0.5,0,"
        "{border_style},{outline},{shadow},2,40,40,90,1"
    ).format(**s)


def _header(key, play_w=720, play_h=1280):
    scale = play_h / 1280.0
    return f"""[Script Info]
ScriptType: v4.00+
PlayResX: {play_w}
PlayResY: {play_h}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
""" + _style_line(key, scale) + """

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""


def _clean_text(text):
    text = re.sub(r"<[^>]+>", "", text).strip().replace("\n", "\\N")
    return text.replace("{", "(").replace("}", ")")


def _to_secs(t):
    h, m, rest = t.split(":")
    s = rest.replace(",", ".")
    return int(h) * 3600 + int(m) * 60 + float(s)


def _to_ass_ts(secs):
    if secs < 0:
        secs = 0
    h = int(secs // 3600)
    m = int((secs % 3600) // 60)
    s = secs % 60
    return f"{h}:{m:02d}:{int(s):02d}.{int(round((s - int(s)) * 100)):02d}"


def _write_ass(ass_path, events, style, play_w=720, play_h=1280):
    with open(ass_path, "w", encoding="utf-8") as f:
        f.write(_header(style, play_w, play_h))
        for s, e, t in events:
            f.write(f"Dialogue: 0,{s},{e},Cap,,0,0,0,,{t}\n")
    return len(events)


def vtt_to_ass(vtt_path, ass_path, offset=0.0, clip_len=None, style="classic",
               play_w=720, play_h=1280):
    """VTT ko styled ASS me badlo. offset ghata kar, bahar wale events drop."""
    with open(vtt_path, encoding="utf-8", errors="ignore") as f:
        content = f.read()
    pattern = re.compile(
        r"(\d{2}:\d{2}:\d{2}[.,]\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2}[.,]\d{3})\s*\n((?:(?!\n\n).)*)",
        re.S,
    )
    events = []
    for m in pattern.finditer(content):
        start, end, text = m.groups()
        text = _clean_text(text)
        if not text:
            continue
        s = _to_secs(start) - offset
        e = _to_secs(end) - offset
        if e <= 0:
            continue
        if clip_len is not None and s >= clip_len:
            continue
        s = max(0.0, s)
        if clip_len is not None:
            e = min(e, clip_len)
        if e <= s:
            continue
        events.append((_to_ass_ts(s), _to_ass_ts(e), text))
    return _write_ass(ass_path, events, style, play_w, play_h)


def segments_to_ass(segments, ass_path, style="classic", clip_len=None,
                    play_w=720, play_h=1280):
    """Whisper segments [(start, end, text)] -> styled ASS."""
    events = []
    for s, e, text in segments:
        text = _clean_text(text)
        if not text:
            continue
        if clip_len is not None and s >= clip_len:
            continue
        s = max(0.0, s)
        if clip_len is not None:
            e = min(e, clip_len)
        if e <= s:
            continue
        events.append((_to_ass_ts(s), _to_ass_ts(e), text))
    return _write_ass(ass_path, events, style, play_w, play_h)
