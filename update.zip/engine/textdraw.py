"""Hook + CTA text overlays — seedha frames par render (no drawtext filter).

imageio-ffmpeg ke bundled FFmpeg binary me `drawtext` filter NAHI hai,
is liye hook/CTA text OpenCV/PIL se frames par draw hota hai —
reframe pass ke andar, resize ke baad. Font sizes frame height ke
hisaab se scale hote hain (720p/1080p/2K/4K sab par sahi dikhen).
"""
import os

import cv2
import numpy as np

try:
    from PIL import Image, ImageDraw, ImageFont
    _PIL = True
except ImportError:
    _PIL = False

_FONT_PATHS = (
    r"C:\Windows\Fonts\arialbd.ttf",
    r"C:\Windows\Fonts\Arial.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
)
_font_cache = {}


def _font(size):
    if not _PIL:
        return None
    if size not in _font_cache:
        f = None
        for p in _FONT_PATHS:
            if os.path.exists(p):
                try:
                    f = ImageFont.truetype(p, size)
                    break
                except Exception:
                    continue
        _font_cache[size] = f
    return _font_cache[size]


def _wrap(draw, text, font, max_w):
    words = text.split()
    lines, cur = [], ""
    for w in words:
        t = (cur + " " + w).strip()
        if draw.textlength(t, font=font) <= max_w:
            cur = t
        else:
            if cur:
                lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines or [text]


def draw_hook(frame, text):
    """Pehle 2.5s: upar dark bar + white bold hook text."""
    if not text:
        return frame
    h, w = frame.shape[:2]
    k = max(h, w) / 1280.0  # resolution scale (9:16 ya 16:9)
    font = _font(int(52 * k))
    if _PIL and font:
        img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        d = ImageDraw.Draw(img, "RGBA")
        lines = _wrap(d, text.upper(), font, w - int(80 * k))
        lh = int(70 * k)
        bar_h = lh * len(lines) + int(36 * k)
        y0 = int(60 * k)
        d.rectangle([0, y0, w, y0 + bar_h], fill=(0, 0, 0, 170))
        y = y0 + int(18 * k) + lh // 2
        for ln in lines:
            d.text((w / 2, y), ln, font=font, fill=(255, 255, 255, 255),
                   anchor="mm", stroke_width=max(1, int(2 * k)),
                   stroke_fill=(0, 0, 0, 255))
            y += lh
        return cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
    # fallback: plain OpenCV text
    f = cv2.FONT_HERSHEY_SIMPLEX
    scale, th = 1.6 * k, max(1, int(3 * k))
    tw, th_ = cv2.getTextSize(text.upper(), f, scale, th)[0]
    while tw > w - 60 and scale > 0.5:
        scale -= 0.2
        tw, th_ = cv2.getTextSize(text.upper(), f, scale, th)[0]
    x = (w - tw) // 2
    y = int(150 * k)
    cv2.rectangle(frame, (0, int(70 * k)), (w, y + th_ + int(30 * k)),
                  (0, 0, 0), -1)
    cv2.putText(frame, text.upper(), (x, y + th_), f, scale,
                (0, 0, 0), th + 3, cv2.LINE_AA)
    cv2.putText(frame, text.upper(), (x, y + th_), f, scale,
                (255, 255, 255), th, cv2.LINE_AA)
    return frame


def draw_cta(frame):
    """Aakhri 3s: full black card + yellow 'Like & Subscribe!'."""
    frame[:] = 0
    h, w = frame.shape[:2]
    k = max(h, w) / 1280.0  # resolution scale (9:16 ya 16:9)
    f1 = _font(int(64 * k))
    f2 = _font(int(44 * k))
    if _PIL and f1 and f2:
        img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        d = ImageDraw.Draw(img)
        d.text((w / 2, h / 2 - int(40 * k)), "Like & Subscribe!", font=f1,
               fill=(255, 215, 0), anchor="mm",
               stroke_width=max(1, int(2 * k)), stroke_fill=(0, 0, 0))
        d.text((w / 2, h / 2 + int(50 * k)), "for more Shorts!", font=f2,
               fill=(255, 255, 255), anchor="mm",
               stroke_width=1, stroke_fill=(0, 0, 0))
        return cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
    f = cv2.FONT_HERSHEY_SIMPLEX
    for txt, y, scale, col in (
            ("Like & Subscribe!", h // 2 - int(30 * k), 1.8 * k,
             (0, 215, 255)),
            ("for more Shorts!", h // 2 + int(60 * k), 1.2 * k,
             (255, 255, 255))):
        tw, th_ = cv2.getTextSize(txt, f, scale, 3)[0]
        x = (w - tw) // 2
        cv2.putText(frame, txt, (x, y), f, scale, (0, 0, 0), 6,
                    cv2.LINE_AA)
        cv2.putText(frame, txt, (x, y), f, scale, col, 3, cv2.LINE_AA)
    return frame


def draw_watermark(frame, text):
    """Top-right corner me halka watermark (channel branding)."""
    if not text:
        return frame
    h, w = frame.shape[:2]
    k = max(h, w) / 1280.0
    font = _font(int(30 * k))
    if _PIL and font:
        img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        d = ImageDraw.Draw(img, "RGBA")
        tw = d.textlength(text, font=font)
        x = w - tw - int(24 * k)
        y = int(24 * k)
        pad_x, pad_y = int(12 * k), int(8 * k)
        d.rectangle([x - pad_x, y - pad_y,
                     x + tw + pad_x, y + int(38 * k)],
                    fill=(0, 0, 0, 110))
        d.text((x, y), text, font=font, fill=(255, 255, 255, 215))
        return cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
    f = cv2.FONT_HERSHEY_SIMPLEX
    scale = 0.8 * k
    tw, _th = cv2.getTextSize(text, f, scale, 2)[0]
    x = w - tw - int(24 * k)
    y = int(48 * k)
    cv2.putText(frame, text, (x, y), f, scale, (255, 255, 255), 2,
                cv2.LINE_AA)
    return frame


# ---------------------------------------------------------------------------
# FAST OVERLAYS (speed fix): static text (hook/watermark/CTA) ko clip shuru
# hone se PEHLE ek dafa render karo. Har frame par PIL + full-frame copies
# nahi — sirf sasta numpy blend. Trick: purane draw_* function ko ek dafa
# KAALE aur ek dafa SAFED background par chalao; dono natijon se har pixel
# ka (fg*alpha, 1-alpha) solve ho jata hai kyunke PIL ka blending background
# me linear hai. Natija purane per-frame rendering jaisa hi (pixel-identical),
# is liye quality me zero farq, speed me 10-30x.
# ---------------------------------------------------------------------------

def _decompose(w, h, draw_fn):
    """draw_fn(frame)->frame se (x0, y0, fg_scaled, inv_alpha) nikalo.

    fg_scaled = fg*alpha (float32), inv_alpha = 1-alpha (float32).
    Per-frame: out = fg_scaled + frame_float * inv_alpha.
    Returns None agar overlay khali ho (kuch draw nahi hua).
    """
    black = np.zeros((h, w, 3), dtype=np.uint8)
    white = np.full((h, w, 3), 255, dtype=np.uint8)
    B = np.asarray(draw_fn(black.copy()), dtype=np.float32)
    W = np.asarray(draw_fn(white.copy()), dtype=np.float32)
    diff = W - B  # 255*(1-alpha) har channel me
    inv_a = (diff[..., 0:1] + diff[..., 1:2] + diff[..., 2:3]) / (3.0 * 255.0)
    inv_a = np.clip(inv_a, 0.0, 1.0)
    ys, xs = np.where(inv_a[..., 0] < 0.999)
    if len(ys) == 0:
        return None
    x0, x1 = int(xs.min()), int(xs.max()) + 1
    y0, y1 = int(ys.min()), int(ys.max()) + 1
    return (x0, y0, B[y0:y1, x0:x1], inv_a[y0:y1, x0:x1])


def blend_overlay(frame, overlay):
    """Pre-rendered overlay ko frame par tez blend karo (numpy only)."""
    if overlay is None:
        return frame
    x0, y0, fg_scaled, inv_alpha = overlay
    hh, ww = fg_scaled.shape[:2]
    roi = frame[y0:y0 + hh, x0:x0 + ww].astype(np.float32)
    frame[y0:y0 + hh, x0:x0 + ww] = (fg_scaled + roi * inv_alpha
                                     ).astype(np.uint8)
    return frame


def make_hook_overlay(w, h, text):
    """Hook overlay ek dafa render -> blend_overlay ke liye, ya None."""
    if not text:
        return None
    return _decompose(w, h, lambda f: draw_hook(f, text))


def make_watermark_overlay(w, h, text):
    """Watermark overlay ek dafa render -> blend_overlay ke liye, ya None."""
    if not text:
        return None
    return _decompose(w, h, lambda f: draw_watermark(f, text))


def make_cta_frame(w, h):
    """CTA full frame ek dafa render -> BGR uint8 (per-frame copyto)."""
    frame = np.zeros((h, w, 3), dtype=np.uint8)
    out = draw_cta(frame)
    return np.ascontiguousarray(out)
