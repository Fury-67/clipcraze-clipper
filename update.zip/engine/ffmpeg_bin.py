"""ffmpeg binary resolve karta hai.

Pehle imageio-ffmpeg ka bundled static binary try hota hai (pip se aata hai,
user ko alag se ffmpeg install nahi karna parta). Na mile to system PATH
wala ffmpeg use hota hai.
"""
import shutil


def get_ffmpeg():
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        pass
    exe = shutil.which("ffmpeg")
    if exe:
        return exe
    raise RuntimeError(
        "ffmpeg nahi mila. 'pip install imageio-ffmpeg' chalao ya ffmpeg install karo."
    )
